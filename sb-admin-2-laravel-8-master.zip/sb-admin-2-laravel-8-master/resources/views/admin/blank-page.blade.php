@extends('layout.backend.app',[
	'title' => 'Blank Page',
	'pageTitle' => 'Blank Page',
])
@section('content')

@stop